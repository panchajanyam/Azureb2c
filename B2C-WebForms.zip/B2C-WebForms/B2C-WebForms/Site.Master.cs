﻿using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;

namespace B2C_WebForms
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}